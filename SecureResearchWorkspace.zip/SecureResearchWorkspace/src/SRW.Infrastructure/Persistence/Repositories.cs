using Microsoft.EntityFrameworkCore;
using SRW.Core.Abstractions;
using SRW.Domain.Entities;

namespace SRW.Infrastructure.Persistence;

public class WorkspaceRepository : IWorkspaceRepository
{
    private readonly SrwDbContext _db;
    public WorkspaceRepository(SrwDbContext db) => _db = db;

    public Task<Workspace?> GetByIdAsync(Guid id, CancellationToken ct = default) =>
        _db.Workspaces
            .Include(w => w.Users)
            .Include(w => w.Applications)
            .FirstOrDefaultAsync(w => w.Id == id, ct);

    public Task<List<Workspace>> ListForUserAsync(string userId, CancellationToken ct = default) =>
        _db.Workspaces
            .Where(w => w.Users.Any(u => u.UserId == userId))
            .Include(w => w.Applications)
            .ToListAsync(ct);

    public async Task AddAsync(Workspace workspace, CancellationToken ct = default)
    {
        await _db.Workspaces.AddAsync(workspace, ct);
        await _db.SaveChangesAsync(ct);
    }

    public Task UpdateAsync(Workspace workspace, CancellationToken ct = default)
    {
        _db.Workspaces.Update(workspace);
        return _db.SaveChangesAsync(ct);
    }

    public Task<List<WorkspaceApplication>> GetApplicationsAsync(Guid workspaceId, CancellationToken ct = default) =>
        _db.WorkspaceApplications.Where(a => a.WorkspaceId == workspaceId && a.Enabled).ToListAsync(ct);

    public Task<WorkspaceApplication?> GetApplicationAsync(Guid applicationId, CancellationToken ct = default) =>
        _db.WorkspaceApplications.FirstOrDefaultAsync(a => a.Id == applicationId, ct);
}

public class SessionRepository : ISessionRepository
{
    private readonly SrwDbContext _db;
    public SessionRepository(SrwDbContext db) => _db = db;

    public Task<UserSession?> GetByIdAsync(Guid id, CancellationToken ct = default) =>
        _db.UserSessions.FirstOrDefaultAsync(s => s.Id == id, ct);

    public Task<UserSession?> GetActiveAsync(Guid wsId, Guid appId, string userId, CancellationToken ct = default) =>
        _db.UserSessions
            .Where(s => s.WorkspaceId == wsId && s.ApplicationId == appId && s.UserId == userId)
            .Where(s => s.Status == SessionStatus.Running || s.Status == SessionStatus.Starting)
            .OrderByDescending(s => s.CreatedAtUtc)
            .FirstOrDefaultAsync(ct);

    public Task<List<UserSession>> ListForUserAsync(Guid wsId, string userId, CancellationToken ct = default) =>
        _db.UserSessions
            .Where(s => s.WorkspaceId == wsId && s.UserId == userId)
            .OrderByDescending(s => s.CreatedAtUtc)
            .ToListAsync(ct);

    public async Task AddAsync(UserSession session, CancellationToken ct = default)
    {
        await _db.UserSessions.AddAsync(session, ct);
        await _db.SaveChangesAsync(ct);
    }

    public Task UpdateAsync(UserSession session, CancellationToken ct = default)
    {
        _db.UserSessions.Update(session);
        return _db.SaveChangesAsync(ct);
    }
}

/// <summary>
/// Stores the per-workspace storage account key encrypted at rest using ASP.NET Core Data Protection.
/// In production swap for Azure Key Vault (one secret per workspace).
/// </summary>
public class WorkspaceSecretStore : IWorkspaceSecretStore
{
    private readonly SrwDbContext _db;
    private readonly Microsoft.AspNetCore.DataProtection.IDataProtector _protector;

    public WorkspaceSecretStore(SrwDbContext db, Microsoft.AspNetCore.DataProtection.IDataProtectionProvider provider)
    {
        _db = db;
        _protector = provider.CreateProtector("SRW.WorkspaceSecrets.v1");
    }

    public async Task SetStorageKeyAsync(Guid workspaceId, string accountKey, CancellationToken ct = default)
    {
        var encrypted = _protector.Protect(System.Text.Encoding.UTF8.GetBytes(accountKey));
        var existing = await _db.WorkspaceSecrets.FindAsync(new object[] { workspaceId }, ct);
        if (existing is null)
        {
            _db.WorkspaceSecrets.Add(new WorkspaceSecret
            {
                WorkspaceId = workspaceId,
                EncryptedValue = encrypted,
                UpdatedAtUtc = DateTime.UtcNow
            });
        }
        else
        {
            existing.EncryptedValue = encrypted;
            existing.UpdatedAtUtc = DateTime.UtcNow;
        }
        await _db.SaveChangesAsync(ct);
    }

    public async Task<string> GetStorageKeyAsync(Guid workspaceId, CancellationToken ct = default)
    {
        var row = await _db.WorkspaceSecrets.FindAsync(new object[] { workspaceId }, ct)
            ?? throw new InvalidOperationException("No storage key on file for workspace");
        var bytes = _protector.Unprotect(row.EncryptedValue);
        return System.Text.Encoding.UTF8.GetString(bytes);
    }

    public async Task DeleteAsync(Guid workspaceId, CancellationToken ct = default)
    {
        var row = await _db.WorkspaceSecrets.FindAsync(new object[] { workspaceId }, ct);
        if (row is not null)
        {
            _db.WorkspaceSecrets.Remove(row);
            await _db.SaveChangesAsync(ct);
        }
    }
}
