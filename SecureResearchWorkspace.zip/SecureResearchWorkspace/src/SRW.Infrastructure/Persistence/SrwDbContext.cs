using Microsoft.EntityFrameworkCore;
using SRW.Domain.Entities;

namespace SRW.Infrastructure.Persistence;

public class SrwDbContext : DbContext
{
    public DbSet<Workspace> Workspaces => Set<Workspace>();
    public DbSet<WorkspaceUser> WorkspaceUsers => Set<WorkspaceUser>();
    public DbSet<WorkspaceApplication> WorkspaceApplications => Set<WorkspaceApplication>();
    public DbSet<UserSession> UserSessions => Set<UserSession>();
    public DbSet<WorkspaceSecret> WorkspaceSecrets => Set<WorkspaceSecret>();

    public SrwDbContext(DbContextOptions<SrwDbContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Workspace>(e =>
        {
            e.ToTable("Workspaces");
            e.HasKey(x => x.Id);
            e.Property(x => x.Name).IsRequired().HasMaxLength(64);
            e.Property(x => x.Description).HasMaxLength(512);
            e.Property(x => x.Status).HasConversion<string>().HasMaxLength(32);
            e.Property(x => x.StorageAccountName).HasMaxLength(24);
            e.Property(x => x.K8sNamespace).HasMaxLength(63);
            e.HasMany(x => x.Users).WithOne().HasForeignKey(u => u.WorkspaceId);
            e.HasMany(x => x.Applications).WithOne().HasForeignKey(a => a.WorkspaceId);
        });

        b.Entity<WorkspaceUser>(e =>
        {
            e.ToTable("WorkspaceUsers");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.WorkspaceId, x.UserId }).IsUnique();
            e.Property(x => x.UserId).IsRequired().HasMaxLength(128);
            e.Property(x => x.Role).HasConversion<string>().HasMaxLength(16);
        });

        b.Entity<WorkspaceApplication>(e =>
        {
            e.ToTable("WorkspaceApplications");
            e.HasKey(x => x.Id);
            e.Property(x => x.Type).HasConversion<string>().HasMaxLength(16);
            e.Property(x => x.ContainerImage).HasMaxLength(256);
        });

        b.Entity<UserSession>(e =>
        {
            e.ToTable("UserSessions");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.WorkspaceId, x.ApplicationId, x.UserId, x.Status });
            e.Property(x => x.Status).HasConversion<string>().HasMaxLength(16);
            e.Property(x => x.UserId).IsRequired().HasMaxLength(128);
        });

        b.Entity<WorkspaceSecret>(e =>
        {
            e.ToTable("WorkspaceSecrets");
            e.HasKey(x => x.WorkspaceId);
            // EncryptedValue is symmetric-encrypted (Data Protection API or Key Vault wrap).
            e.Property(x => x.EncryptedValue).IsRequired();
        });
    }
}

public class WorkspaceSecret
{
    public Guid WorkspaceId { get; set; }
    public byte[] EncryptedValue { get; set; } = default!;
    public DateTime UpdatedAtUtc { get; set; }
}
