using SRW.Api.Auth;
using SRW.Core.Abstractions;
using SRW.Core.Services;
using SRW.Domain.Entities;

namespace SRW.Api.Endpoints;

public static class SessionEndpoints
{
    public static void MapSessionEndpoints(this WebApplication app)
    {
        var grp = app.MapGroup("/api/workspaces/{workspaceId:guid}/sessions").WithTags("Sessions");

        // Launch a session (idempotent — returns existing if already running)
        grp.MapPost("/", async (
            Guid workspaceId,
            LaunchSessionDto dto,
            SessionLauncher launcher,
            ICurrentUser user,
            CancellationToken ct) =>
        {
            try
            {
                var session = await launcher.LaunchAsync(workspaceId, dto.ApplicationId, user.UserId, ct);
                return Results.Ok(SessionResponse.From(session));
            }
            catch (InvalidOperationException ex)
            {
                return Results.BadRequest(new { error = ex.Message });
            }
        });

        // List my sessions in this workspace
        grp.MapGet("/", async (
            Guid workspaceId,
            ISessionRepository repo,
            ICurrentUser user,
            IKubernetesOrchestrator k8s,
            IWorkspaceRepository wsRepo,
            CancellationToken ct) =>
        {
            var sessions = await repo.ListForUserAsync(workspaceId, user.UserId, ct);
            var ws = await wsRepo.GetByIdAsync(workspaceId, ct);
            if (ws is null) return Results.NotFound();

            // Refresh status from K8s for active sessions
            foreach (var s in sessions.Where(s => s.Status is SessionStatus.Starting or SessionStatus.Running))
            {
                s.Status = await k8s.GetSessionStatusAsync(ws.K8sNamespace, s.DeploymentName, ct);
            }

            return Results.Ok(sessions.Select(SessionResponse.From));
        });

        // Get one session
        grp.MapGet("/{sessionId:guid}", async (
            Guid sessionId,
            ISessionRepository repo,
            CancellationToken ct) =>
        {
            var s = await repo.GetByIdAsync(sessionId, ct);
            return s is null ? Results.NotFound() : Results.Ok(SessionResponse.From(s));
        });

        // Stop a session
        grp.MapDelete("/{sessionId:guid}", async (
            Guid sessionId,
            SessionLauncher launcher,
            CancellationToken ct) =>
        {
            await launcher.StopAsync(sessionId, ct);
            return Results.NoContent();
        });
    }
}

public record LaunchSessionDto(Guid ApplicationId);

public record SessionResponse(
    Guid Id,
    Guid WorkspaceId,
    Guid ApplicationId,
    string Status,
    string? AccessUrl,
    DateTime CreatedAtUtc,
    DateTime? StartedAtUtc)
{
    public static SessionResponse From(UserSession s) => new(
        s.Id, s.WorkspaceId, s.ApplicationId,
        s.Status.ToString(), s.AccessUrl,
        s.CreatedAtUtc, s.StartedAtUtc);
}
