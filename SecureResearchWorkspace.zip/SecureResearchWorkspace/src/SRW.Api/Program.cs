using Microsoft.EntityFrameworkCore;
using SRW.Core.Abstractions;
using SRW.Core.Services;
using SRW.Infrastructure.Azure;
using SRW.Infrastructure.Kubernetes;
using SRW.Infrastructure.Persistence;
using SRW.Api.Endpoints;
using SRW.Api.Auth;

var builder = WebApplication.CreateBuilder(args);

// ── Configuration ─────────────────────────────────────────────────────────────
builder.Services.Configure<AzureOptions>(builder.Configuration.GetSection("Azure"));

// ── Persistence ───────────────────────────────────────────────────────────────
builder.Services.AddDbContext<SrwDbContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("Sql")));

builder.Services.AddDataProtection();

builder.Services.AddScoped<IWorkspaceRepository, WorkspaceRepository>();
builder.Services.AddScoped<ISessionRepository, SessionRepository>();
builder.Services.AddScoped<IWorkspaceSecretStore, WorkspaceSecretStore>();

// ── Infrastructure adapters ───────────────────────────────────────────────────
builder.Services.AddSingleton<IAzureStorageProvisioner, AzureStorageProvisioner>();
builder.Services.AddSingleton<IKubernetesOrchestrator, KubernetesOrchestrator>();

// ── Application services ──────────────────────────────────────────────────────
builder.Services.AddScoped<WorkspaceProvisioningService>();
builder.Services.AddScoped<SessionLauncher>();

// ── Auth (placeholder — wire Keycloak later via OIDC) ─────────────────────────
builder.Services.AddCurrentUserAccessor();

// ── Web ───────────────────────────────────────────────────────────────────────
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors();
app.UseCurrentUser();    // sets ICurrentUser per request — replace with real OIDC middleware later

app.MapWorkspaceEndpoints();
app.MapSessionEndpoints();
app.MapApplicationEndpoints();

app.MapGet("/health", () => Results.Ok(new { status = "ok" }));

app.Run();
